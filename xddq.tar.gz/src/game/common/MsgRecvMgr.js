import logger from "#utils/logger.js";
import Protocol from "#game/net/Protocol.js";
import GameNetMgr from "#game/net/GameNetMgr.js";
import CustomMgr from "#game/mgr/CustomMgr.js";
import BagMgr from "#game/mgr/BagMgr.js";
import FrogMgr from "#game/mgr/FrogMgr.js";
import DestinyMgr from "#game/mgr/DestinyMgr.js";
import UserMgr from "#game/mgr/UserMgr.js";
import SpiritMgr from "#game/mgr/SpiritMgr.js";
import PlayerAttributeMgr from "#game/mgr/PlayerAttributeMgr.js";
import PalaceMgr from "#game/mgr/PalaceMgr.js";
import MagicMgr from "#game/mgr/MagicMgr.js";
import MagicTreasureMgr from "#game/mgr/MagicTreasureMgr.js";
import PupilMgr from "#game/mgr/PupilMgr.js";
import GatherEnergyMgr from "#game/mgr/GatherEnergyMgr.js";
import WildBossMgr from "#game/mgr/WildBossMgr.js";
import TowerMgr from "#game/mgr/TowerMgr.js";
import ChapterMgr from "#game/mgr/ChapterMgr.js";
import SecretTowerMgr from "#game/mgr/SecretTowerMgr.js";
import HeroRankMgr from "#game/mgr/HeroRankMgr.js";
import ActivityMgr from "#game/mgr/ActivityMgr.js";
import UnionMgr from "#game/mgr/UnionMgr.js";
import HomelandMgr from "#game/mgr/HomelandMgr.js";
import InvadeMgr from "#game/mgr/InvadeMgr.js";
import StarTrialMgr from "#game/mgr/StarTrialMgr.js";
import RuleTrialMgr from "#game/mgr/RuleTrialMgr.js";
import PetMgr from "#game/mgr/PetMgr.js";
import UniverseMgr from "#game/mgr/UniverseMgr.js";
import YueBaoMgr from "#game/mgr/YueBaoMgr.js";
import YardDpbMgr from "#game/mgr/YardDpbMgr.js";
import UnionTreasureMgr from "#game/mgr/UnionTreasureMgr.js";
import SystemUnlockMgr from "#game/mgr/SystemUnlockMgr.js";
import UnionBountyMgr from "#game/mgr/UnionBountyMgr.js";
import DBMgr from "#game/common/DBMgr.js";
import SkyWarMgr from "#game/mgr/SkyWarMgr.js";
import TownDemonMgr from "#game/mgr/TownDemonMgr.js";
import CareerMgr from "#game/mgr/CareerMgr.js";
import MailRewardMgr from "#game/mgr/MailMgr.js";

class MsgRecvMgr {
  constructor() {}

  // 101 用户信息同步
  static PlayerDataMsg(t) {
    UserMgr.nickName = t.nickName;
    UserMgr.playerId = t.playerId;
    UserMgr.roleId = t.roleId;
    UserMgr.serverId = Number(t.serverId);

    // 推送用户名姓名
    logger.info(
      `{"wxHeadUrl":"${t.wxHeadUrl}","nickName":"${t.nickName}","playerBelong":"${t.playerBelong}","playerId":"${t.playerId}"}`
    );
  }

  // 102 系统解锁同步
  static SystemUnlockSync(t) {
    logger.debug("[MsgRecvMgr] 同步系统解锁");
    SystemUnlockMgr.inst.SyncData(t);
  }

  // 104 同步特权卡数据
  static PrivilegeCardDataMsg(t) {
    logger.debug("[MsgRecvMgr] 同步特权卡数据");
    PlayerAttributeMgr.inst.SyncVip(t);
  }

  // 201 玩家属性信息同步
  static PlayerAttributeDataMsg(t) {
    logger.debug("[MsgRecvMgr] 玩家属性信息同步");
    PlayerAttributeMgr.inst.SyncAttribute(t);
  }

  // 207 树状态
  static DreamDataMsg(t) {
    logger.debug("[MsgRecvMgr] 树状态同步");
    PlayerAttributeMgr.inst.SyncTree(t);
    // 初始化完成后 自定义管理器初始化
    CustomMgr.inst.init();
  }

  // 209 获取未处理装备数据
  static GetUnDealEquipmentMsgResp(t) {
    logger.debug("[MsgRecvMgr] 获取未处理装备数据");
    PlayerAttributeMgr.inst.handlerEquipment(t);
  }

  // 210 青蛙
  static PlayerAdRewardDataMsg(t) {
    logger.debug("[MsgRecvMgr] 青蛙数据同步");
    FrogMgr.inst.checkReward(t);
  }

  // 215 同步分身数据
  static GetSeparationDataMsgListResp(t) {
    logger.debug("[MsgRecvMgr] 同步分身数据");
    PlayerAttributeMgr.inst.checkSeparation(t);
  }

  static SwitchSeparationResp(t) {
    logger.debug("[MsgRecvMgr] 切换分身后数据返回");
    PlayerAttributeMgr.inst.switchSeparationResp(t);
  }

  // 301 同步背包数据
  static SyncBagMsg(t) {
    logger.debug("[MsgRecvMgr] 背包数据同步");
    BagMgr.inst.SyncBagMsg(t);
  }

  // 621 同步灵脉数据
  static TalentPlayerDataMsg(t) {
    logger.debug("[MsgRecvMgr] 灵脉数据同步");
    PlayerAttributeMgr.inst.handlerTalentInit(t);
  }

  // 625 获取未处理灵脉数据
  static GetUnDealTalentMsgResp(t) {
    logger.debug("[MsgRecvMgr] 获取未处理灵脉数据");
    PlayerAttributeMgr.inst.handlerTalent(t);
  }

  // 651 游历数据同步
  static DestinyData(t) {
    logger.debug("[MsgRecvMgr] 游历数据同步");
    DestinyMgr.inst.SyncData(t);
  }

  // 821 同步玩家精怪数据
  static SpiritPlayerDataMsg(t) {
    logger.debug("[MsgRecvMgr] 精怪数据同步");
    // TODO: SpiritMgr.inst.syncSpiritPlayerDataMsg(t);
    SpiritMgr.inst.checkReward(t);
  }

  // 2117 妖盟数据 同步妖盟任务
  static RspUnionDailyTask(t) {
    logger.debug("[MsgRecvMgr] 同步妖盟任务");
    UnionMgr.inst.checkDailyTask(t);
  }

  // 2124 妖盟数据 推送我的妖盟数据更新
  static MyUnionData(t) {
    logger.debug("[MsgRecvMgr] 妖盟数据同步");
    UnionMgr.inst.pushMyUnionDataBroadcast(t);
    UnionTreasureMgr.inst.pushMyUnionDataBroadcast(t);
    UnionBountyMgr.inst.pushMyUnionDataBroadcast(t);
  }

  // 2165 妖盟砍价数据同步
  static CutPriceDataMsg(t) {
    logger.debug("[MsgRecvMgr] 妖盟砍价数据同步");
    UnionMgr.inst.cutPriceSyncData(t);
  }

  // 5801 主动请求布阵信息 满20层开打
  static UnionBossInfoRespMsg(t) {
    logger.debug("[MsgRecvMgr] 妖盟讨伐boss信息同步");
    UnionMgr.inst.SyncUnionBossMsg(t);
  }

  // 5803 妖盟讨伐boss战斗 是否可以领奖
  static UnionBossRewardRespMsg(t) {
    logger.debug("[MsgRecvMgr] 妖盟讨伐boss战斗结果");
    UnionMgr.inst.BossReward(t);
  }

  //6730 妖盟夺位战数据同步
  static UnionFightApplyDataSync(t) {
    logger.debug("[MsgRecvMgr] 妖盟请战");
    UnionMgr.inst.UnionFightApplyDataSync(t);
  }

  // 4802 仙宫点赞同步
  static PalaceWorshipRsp(t) {
    logger.debug("[MsgRecvMgr] 仙宫点赞同步");
    PalaceMgr.inst.PalaceWorshipRsp(t);
  }

  // 4803 仙宫外部数据请求
  static EnterPalaceRsp(t) {
    logger.debug("[MsgRecvMgr] 仙宫外部数据请求");
    PalaceMgr.inst.checkWorship(t);
  }

  // 4808 仙宫送福数据同步
  static SendGiftSyncMsg(t) {
    logger.debug("[MsgRecvMgr] 仙宫送福数据同步");
    PalaceMgr.inst.checkReward(t);
  }

  // 4809 仙宫神迹同步
  static PalaceMiracleDataMsg(t) {
    logger.debug("[MsgRecvMgr] 仙宫神迹同步");
    PalaceMgr.inst.checkMiracle(t);
  }

  // 11801 进入宗门系统
  static EnterPupilSystemResp(t) {
    logger.debug("[MsgRecvMgr] 进入宗门系统");
    PupilMgr.inst.checkReward(t);
    PupilMgr.inst.checkGraduatation(t);
  }

  // 4400 神通数据同步
  static PlayerMagicDataMsg(t) {
    logger.debug("[MsgRecvMgr] 神通数据同步");
    // TODO: MagicMgr.inst.syncMagicDataMsg(t);
    MagicMgr.inst.checkReward(t);
  }

  // 6301 玩家法宝数据同步
  static MagicTreasurePlayerDataMsg(t) {
    logger.debug("[MsgRecvMgr] 法宝数据同步");
    MagicTreasureMgr.inst.checkReward(t);
  }

  // 7001 聚灵阵状态
  static GatherEnergyEnterNewResp(t) {
    logger.debug("[MsgRecvMgr] 聚灵阵状态同步");
    GatherEnergyMgr.inst.checkReward(t);
  }

  // 207020 打开聚灵阵一级列表界面（参与人数）
  static GatherEnergyFirstListViewResp(t) {
    logger.debug("[MsgRecvMgr] 聚灵阵状态同步");
    GatherEnergyMgr.inst.GatherEnergyFirstListViewResp(t);
  }

  // 402 关卡挑战
  static ChallengeRspMsg(t) {
    logger.debug("[MsgRecvMgr] 关卡挑战");
    ChapterMgr.inst.challengeResult(t);
  }

  // 403 同步冒险关卡数据
  static PlayerStageData(t) {
    logger.debug("[MsgRecvMgr] 冒险关卡数据同步");
    ChapterMgr.inst.SyncData(t);
  }

  // 551 邮件列表数据同步
  static MailListMsg(t) {
    logger.debug("[MsgRecvMgr] 一键领取邮件奖励");
    MailRewardMgr.inst.MailListMsg(t);
  }

  // 602 是否能购买物品
  static MallBuyCountListMsg(t) {
    logger.debug("[MsgRecvMgr] 是否能购买物品");
    BagMgr.inst.checkBuyGoods(t);
  }

  // 731 妖王数据同步
  static WildBossDataSync(t) {
    logger.debug("[MsgRecvMgr] 妖王数据同步");
    WildBossMgr.inst.checkReward(t);
  }

  // 732 妖王挑战结果
  static WildBossChallengeResp(t) {
    logger.debug("[MsgRecvMgr] 妖王挑战结果");
    WildBossMgr.inst.challengeResult(t);
  }

  // 761 镇妖塔数据同步
  static TowerDataMsg(t) {
    logger.debug("[MsgRecvMgr] 同步镇妖塔数据");
    TowerMgr.inst.SyncData(t);
  }

  // 762 镇妖塔挑战结果
  static TowerChallengeResp(t) {
    logger.debug("[MsgRecvMgr] 镇妖塔挑战结果");
    TowerMgr.inst.challengeResult(t);
  }

  // 5602 真火秘境战斗结果
  static SecretTowerFightResp(t) {
    logger.debug("[MsgRecvMgr] 真火秘境战斗结果");
    SecretTowerMgr.inst.challengeResult(t);
  }

  // 5605 真火秘境 秘境数据同步
  static SynSecretTowerInfo(t) {
    logger.debug("[MsgRecvMgr] 真火秘境数据同步");
    SecretTowerMgr.inst.SyncData(t);
  }

  // 3701 群英榜 同步玩家信息
  static SynHeroRankPlayerInfo(t) {
    logger.debug("[MsgRecvMgr] 群英榜 同步玩家信息");
    HeroRankMgr.inst.SyncData(t.playerInfo);
  }

  // 3702 群英榜 同步玩家排行榜
  static RspHeroRankFightPlayerList(t) {
    logger.debug("[MsgRecvMgr] 群英榜 同步玩家排行榜");
    HeroRankMgr.inst.getFightList(t);
  }

  // 3703 群英榜 请求挑战玩家
  static RspHeroRankFight(t) {
    logger.debug("[MsgRecvMgr] 群英榜 请求挑战玩家");
    HeroRankMgr.inst.doFight(t);
  }

  // 1001 活动通用数据同步
  static PushActivityList(t) {
    logger.debug("[MsgRecvMgr] 活动通用数据同步");
    ActivityMgr.inst.SyncData(t);
  }

  // // 1002 同步活动详细配置
  static ActivityCommonDataListSync(t) {
    logger.debug("[MsgRecvMgr] 活动通用数据同步");
    ActivityMgr.inst.ActivityCommonDataListSync(t);
  }

  // 1007 活动 增量同步活动数据
  static ActivityConditionDataListSync(t) {
    logger.debug("[MsgRecvMgr] 增量同步数据");
  }

  // // 1003 活动 活动详情返回
  static RspGetActivityDetail(t) {
    logger.debug("[MsgRecvMgr] 活动详情返回");
    ActivityMgr.inst.RspGetActivityDetail(t);
  }

  //解析活动奖励返回
  static RspGetActivityConditionReward(t) {
    logger.debug("[MsgRecvMgr] 解析活动奖励返回");
    if (t.ret == 0) {
      const rewardsArray = t.rewards.split("|");
      rewardsArray.forEach((reward) => {
        const [key, value] = reward.split("=");
        const rewardName = DBMgr.inst.getLanguageWord(`Items-${key}`);
        logger.info(`[活动管理] 获得: ${rewardName} 数量: ${value} `);
      });
    }
  }

  // 1051 同步福地鼠宝数据
  static SyncHomelandMsg(t) {
    logger.debug("[MsgRecvMgr] 同步福地鼠宝数据");
    HomelandMgr.inst.doInit(t);
  }

  // 1052 进入福地
  static HomelandEnterResp(t) {
    logger.debug("[MsgRecvMgr] 进入福地");
    HomelandMgr.inst.doEnter(t);
  }

  // 1053 福地管理界面
  static HomelandManageResp(t) {
    logger.debug("[MsgRecvMgr] 同步福地鼠宝数据");
    HomelandMgr.inst.doManage(t);
  }

  // 1058 福地探寻
  static HomelandExploreResp(t) {
    logger.debug("[MsgRecvMgr] 福地探寻");
    HomelandMgr.inst.doExplore(t);
  }

  // 1402 异兽入侵数据同步
  static InvadeDataMsg(t) {
    logger.debug("[MsgRecvMgr] 异兽入侵挑战");
    InvadeMgr.inst.InvadeDataMsg(t);
  }

  // 1401 异兽入侵挑战结果
  static InvadeChallengeResp(t) {
    logger.debug("[MsgRecvMgr] 异兽入侵用户数据同步");
    InvadeMgr.inst.InvadeChallengeResp(t);
  }

  // 206901星宿试炼数据同步
  static StarTrialDataMsg(t) {
    logger.debug("[MsgRecvMgr] 星宿试炼数据同步");
    StarTrialMgr.inst.StarTrialDataMsg(t);
  }

  // 206902星宿试炼挑战返回
  static StarTrialChallengeResp(t) {
    logger.debug("[MsgRecvMgr] 星宿试炼挑战返回");
    StarTrialMgr.inst.StarTrialChallengeResp(t);
  }

  // 9105 法则试练速战数据同步
  static RuleTrialDataSync(t) {
    logger.debug("[MsgRecvMgr] 法则试练速战数据同步");
    RuleTrialMgr.inst.RuleTrialDataSync(t);
  }

  // 740 同步玩家灵兽数据
  static PlayerPetDataSync(t) {
    logger.debug("[MsgRecvMgr] 同步玩家灵兽数据");
    PetMgr.inst.SyncPlayerPetDataMsg(t.playerPetData);
  }

  // 20742 灵兽刷新返回结果
  static RefreshPetPoolResp(t) {
    logger.debug("[MsgRecvMgr] 同步玩家灵兽数据");
    PetMgr.inst.RefreshPetPoolResp(t);
  }

  // 14302 小世界信息同步
  static UniverseDataMsgSync(t) {
    logger.debug("[MsgRecvMgr] 小世界信息同步");
    UniverseMgr.inst.UniverseDataMsgSync(t);
  }

  // 214304 天地轮盘抽奖结果
  static UniverseDrawResp(t) {
    logger.debug("[MsgRecvMgr] 天地轮盘抽奖结果");
    UniverseMgr.inst.UniverseDrawResp(t);
  }

  // 214310 天地轮盘二次抽奖结果
  static UniverseDrawTwiceResp(t) {
    logger.debug("[MsgRecvMgr] 天地轮盘二次抽奖结果");
    UniverseMgr.inst.UniverseDrawTwiceResp(t);
  }

  // 17001 仙玉宝府进入请求
  static YueBaoEnterResp(t) {
    logger.debug("[MsgRecvMgr] 仙玉宝府进入请求");
    YueBaoMgr.inst.checkStatus(t);
  }

  // 216207 妖盟寻宝
  static UnionTreasureEnterResp(t) {
    logger.debug("[MsgRecvMgr] 进入妖盟寻宝");
    UnionTreasureMgr.inst.UnionTreasureEnterResp(t);
  }

  //15843 仙居登录同步
  static YardLoginSync(t) {
    logger.debug("[MsgRecvMgr] 仙居登录同步");
    YardDpbMgr.inst.YardLoginSync(t);
  }

  //15801 仙居-进入
  static YardEnterResp(t) {
    logger.debug("[MsgRecvMgr] 仙居-进入同步");
    YardDpbMgr.inst.YardEnterResp(t);
  }

  //15849 家园生产信息同步
  static YardMakeMsgSync(t) {
    logger.debug("[MsgRecvMgr] 家园生产信息同步");
    YardDpbMgr.inst.YardMakeMsgSync(t);
  }

  //213602 进入妖盟悬赏返回
  static UnionBountyEnterMapResp(t) {
    logger.debug("[MsgRecvMgr] 进入妖盟悬赏同步");
    UnionBountyMgr.inst.UnionBountyEnterMapResp(t);
  }

  //213614 押镖界面
  static UnionBountyOpenBountyEventResp(t) {
    logger.debug("[MsgRecvMgr] 押镖界面");
    UnionBountyMgr.inst.UnionBountyOpenBountyEventResp(t);
  }

  static UnionBountyOpenMonsterResp(t) {
    logger.debug("[MsgRecvMgr] 妖兽打开返回结果");
    UnionBountyMgr.inst.UnionBountyOpenMonsterResp(t);
  }

  static SkyWarDataSync(t) {
    logger.debug("[MsgRecvMgr] 征战诸天初始化");
    SkyWarMgr.inst.SkyWarDataSync(t);
  }

  // 208401 征战诸天初始化
  static SkyWarEnterRsp(t) {
    logger.debug("[MsgRecvMgr] 进入征战诸天初始化");
    SkyWarMgr.inst.SkyWarEnterRsp(t);
  }

  // 208409 征战诸天，诸天榜
  static SkyWarSkyRankRsp(t) {
    logger.debug("[MsgRecvMgr] 征战诸天，诸天榜单");
    SkyWarMgr.inst.SkyWarSkyRankRsp(t);
  }

  // 208403 征战诸天决斗后返回结果
  static SkyWarFightRsp(t) {
    logger.debug("[MsgRecvMgr] 征战诸天决斗后返回结果");
    SkyWarMgr.inst.SkyWarFightRsp(t);
  }

  // 208402 刷新对手返回结果
  static SkyWarRefreshEnemyRsp(t) {
    logger.debug("[MsgRecvMgr] 征战诸天刷新对手返回结果");
    SkyWarMgr.inst.SkyWarRefreshEnemyRsp(t);
  }

  // TODO 以下暂时不想写

  // import CommonRedPacketMgr from "#game/mgr/CommonRedPacketMgr.js";
  //     // 140 红包状态同步 TODO 自动领取
  //     static RedPacketStateMsgSync(t) {
  //         logger.debug("[MsgRecvMgr] 红包状态同步");
  //         CommonRedPacketMgr.inst.syncRedPacketState(t);
  //     }

  // import EquipmentAdvanceMgr from "#game/mgr/EquipmentAdvanceMgr.js";
  //     // 5504 装备精炼数据同步
  //     static EquipmentAdvanceDataMsg(t) {
  //         logger.debug("[MsgRecvMgr] 装备精炼数据同步");
  //         EquipmentAdvanceMgr.inst.syncEquipmentData(t);
  //     }

  // === 顶号通知 ===
  static OtherLoginMsg(t) { GameNetMgr.inst.onKickedByPhone(); }

  // === 任务管理 ===
  static TaskDataListMsg(t, e) {
    if (!t) return;
    if (e == Protocol.getProtocalIdRemainder(Protocol.S_TASK_DATA_SEND)) {
      logger.debug("[MsgRecvMgr] 任务全量同步");
      TaskMgr.inst.initTaskList(t);
    } else {
      logger.debug("[MsgRecvMgr] 任务增量同步");
      TaskMgr.inst.syncTaskList(t);
    }
  }
  static TaskGetRewardRespMsg(t) {
    if (!t) return;
    logger.debug("[MsgRecvMgr] 任务奖励领取返回");
    TaskMgr.inst.onGetRewardResp(t);
  }

  // === 斗法 ===
  static GetBattleListResp(t) {
    if (!t) return;
    logger.debug("[MsgRecvMgr] 斗法对手列表");
    BagMgr.inst.handleRankBattleList(t);
  }
  static RankBattleChallengeResp(t) {
    if (!t) return;
    logger.debug("[MsgRecvMgr] 斗法挑战结果");
    BagMgr.inst.handleRankBattleResult(t);
  }

  // === 镇魔管理 ===
  static TownDemonApplyDataSync(t) { if(!t)return; logger.debug("[镇魔]登录同步"); TownDemonMgr.inst.onApplyDataSync(t); }
  static TownDemonTimeStampsDataSync(t) { if(!t)return; logger.debug("[镇魔]时间戳"); TownDemonMgr.inst.onTimeStampsSync(t); }
  static TownDemonBaseInfoRespMsg(t) { if(!t)return; logger.debug("[镇魔]主界面"); TownDemonMgr.inst.onBaseInfoResp(t); }
  static TownDemonBattleRespMsg(t) { if(!t)return; logger.debug("[镇魔]挑战结果"); TownDemonMgr.inst.onBattleResp(t); }
  static TowerDemonGetAchieveInfoRespMsg(t) { if(!t)return; logger.debug("[镇魔]成就"); TownDemonMgr.inst.onAchieveInfoResp(t); }
  static TownDemonAchieveRewardRespMsg(t) { if(!t)return; logger.debug("[镇魔]成就奖励"); TownDemonMgr.inst.onAchieveRewardResp(t); }
  static TownDemonGetRewardInfoRespMsg(t) { if(!t)return; logger.debug("[镇魔]排行信息"); TownDemonMgr.inst.onRewardInfoResp(t); }
  static TownDemonGetRankRewardRespMsg(t) { if(!t)return; logger.debug("[镇魔]排行奖励"); TownDemonMgr.inst.onRankRewardResp(t); }

  // === 宗门管理 ===
  static PupilSystemLoginSync(t) { if(!t)return; logger.debug("[MsgRecvMgr]宗门登录"); PupilMgr.inst.checkReward(t); }
  static EnterPupilSystemResp(t) { if(!t)return; logger.debug("[MsgRecvMgr]进入宗门"); PupilMgr.inst.checkGraduatation(t); }
  static PupilGraduateResp(t) { if(t.ret===0)logger.info("[宗门]出师成功");else logger.warn("[宗门]出师失败"); }
  static PupilRecruitResp(t) { if(t.ret===0)logger.info("[宗门]招募成功");else logger.warn("[宗门]招募失败"); }
  static PupilTrainResp(t) { if(t.ret===0)logger.debug("[宗门]锤炼成功");else logger.warn("[宗门]锤炼失败"); }

  // === 道途管理 ===
  static CareerPlayerDataMsg(t) { if(!t)return; logger.debug("[MsgRecvMgr]道途数据"); CareerMgr.inst.onPlayerDataSync(t); }
  static CareerTrainResp(t) { if(!t)return; logger.debug("[MsgRecvMgr]道途修行"); CareerMgr.inst.onTrainResp(t); }
  static CareerBattleBossResp(t) { if(!t)return; logger.debug("[MsgRecvMgr]道途boss"); CareerMgr.inst.onBattleBossResp(t); }
  static CareerGetBossAttrResp(t) { if(!t)return; logger.debug("[MsgRecvMgr]道途属性"); CareerMgr.inst.onBossAttrResp(t); }
  static CareerGetPreTaskRewardResp(t) { if(!t)return; logger.debug("[MsgRecvMgr]任务奖励"); CareerMgr.inst.onPreTaskRewardResp(t); }
  static CareerSwitchCareerResp(t) { if(!t)return; logger.debug("[MsgRecvMgr]切换道途"); CareerMgr.inst.onSwitchCareerResp(t); }
  static CareerGetAttrMapResp(t) { if(!t)return; logger.debug("[MsgRecvMgr]属性映射"); CareerMgr.inst.onGetAttrMapResp(t); }
}

export default MsgRecvMgr;
