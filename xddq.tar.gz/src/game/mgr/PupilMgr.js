import GameNetMgr from "#game/net/GameNetMgr.js";
import Protocol from "#game/net/Protocol.js";
import logger from "#utils/logger.js";
import SystemUnlockMgr from "#game/mgr/SystemUnlockMgr.js";
import LoopMgr from "#game/common/LoopMgr.js";
import AdRewardMgr from "#game/mgr/AdRewardMgr.js";

export default class PupilMgr {
    constructor() {
        this.AD_REWARD_DAILY_MAX_NUM = 2;   // 每日最大领取次数
        this.AD_REWARD_CD = 1000;           // 每次间隔时间
        this.isProcessing = false;
        this.lastLoopCheckTime = 0;
        this.LOOP_CHECK_CD = 5 * 60 * 1000;
        this.initialized = false;
    }

    static get inst() {
        if (!SystemUnlockMgr.PUPIL) {
            logger.warn(`[宗门管理] ${global.colors.red}系统未解锁${global.colors.reset}`);
            return null;
        }

        if (!this._instance) {
            this._instance = new PupilMgr();
        }
        return this._instance;
    }

    reset() {
        this._instance = null;
    }

    clear() {
        LoopMgr.inst.remove(this);
    }

    checkReward(t) {
        this.isProcessing = true;
        this.getAdRewardTimes = t.getTimes || 0;
        this.lastAdRewardTime = 0;
        this.isProcessing = false;
        this.initialized = true;
    }

    countElementsWithoutPupilData(siteList) {
        return siteList.filter((site) => !site.hasOwnProperty("pupilData")).length;
    }

    getGraduationIndices(siteList) {
        return siteList
            .filter((site) => site.pupilData && site.trainTimeInfo && site.pupilData.level * 20 <= site.trainTimeInfo.trainTimes)
            .map((site) => site.index);
    }

    // 毕业→结伴→招人→锤炼
    async checkGraduatation(t) {
        if (!global.account.switch.pupil) {
            return;
        }
        if (t.ret === 0) {
            // 先毕业
            const graduationIndices = this.getGraduationIndices(t.siteList);
            if (graduationIndices.length > 0) {
                logger.info(`[宗门管理] 出师 ${graduationIndices.length} 人`);
                for (let i = 0; i < graduationIndices.length; i++) {
                    GameNetMgr.inst.sendPbMsg(Protocol.S_PUPIL_GRADUATE, { siteIndex: graduationIndices[i] });
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                }
                // 有毕业 → 获取毕业生列表以便结伴
                this._pendingPartner = true;
                GameNetMgr.inst.sendPbMsg(Protocol.S_PUPIL_GET_GRADUATE_LIST, { type: 0 });
                return;
            }

            // 没毕业但有毕业生待结伴 → 获取列表
            if (t.allGraduatedNums > 0 || this._pendingPartner) {
                this._pendingPartner = true;
                GameNetMgr.inst.sendPbMsg(Protocol.S_PUPIL_GET_GRADUATE_LIST, { type: 0 });
                return;
            }

            // 招人（有席位空着才招）
            const invitationCount = this.countElementsWithoutPupilData(t.siteList);
            if (invitationCount > 0) {
                logger.info(`[宗门管理] 招 ${invitationCount} 人`);
                for (let i = 0; i < invitationCount; i++) {
                    GameNetMgr.inst.sendPbMsg(Protocol.S_PUPIL_RECRUIT, {});
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                }
            }

            // 锤炼
            GameNetMgr.inst.sendPbMsg(Protocol.S_PUPIL_TRAIN, { isOneKey: 1 });
        }
    }

    processReward() {
        const now = Date.now();
        if (this.getAdRewardTimes < this.AD_REWARD_DAILY_MAX_NUM && now - this.lastAdRewardTime >= this.AD_REWARD_CD) {
            const logContent = `[宗门管理] 还剩 ${this.AD_REWARD_DAILY_MAX_NUM - this.getAdRewardTimes} 次广告激励`;
            AdRewardMgr.inst.AddAdRewardTask({ protoId: Protocol.S_PUPIL_GET_AD_REWARD, data: { isUseADTime: false }, logStr: logContent });
            this.getAdRewardTimes++;
            this.lastAdRewardTime = now;
        }
    }

    async loopUpdate() {
        if (this.isProcessing) return;
        this.isProcessing = true;

        try {

            // 每五分钟进入宗门一次
            if (Date.now() - this.lastLoopCheckTime >= this.LOOP_CHECK_CD) {
                this.initialized = false;
                // 进入宗门系统
                GameNetMgr.inst.sendPbMsg(Protocol.S_PUPIL_ENTER, {});
                this.lastLoopCheckTime = Date.now();
            }

            if (!this.initialized) {
                return;
            }

            if (this.getAdRewardTimes >= this.AD_REWARD_DAILY_MAX_NUM) {
                logger.debug("[宗门管理] 达到每日最大领取次数，停止奖励领取");
            } else {
                this.processReward();
            }
        } catch (error) {
            logger.error(`[宗门管理] loopUpdate error: ${error}`);
        } finally {
            this.isProcessing = false;
        }
    }
}
